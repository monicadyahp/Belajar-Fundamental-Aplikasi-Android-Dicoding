package com.example.apijadi

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.text.Html
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailEventFragment : Fragment() {

    private lateinit var imageView: ImageView
    private lateinit var nameTextView: TextView
    private lateinit var ownerTextView: TextView
    private lateinit var timeTextView: TextView
    private lateinit var quotaTextView: TextView
    private lateinit var descriptionTextView: TextView
    private lateinit var linkButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var noInternetText: TextView
    private lateinit var favoriteButton: ImageView

    private lateinit var viewModel: DetailEventViewModel
    private lateinit var favoriteEventViewModel: FavoritEventViewModel
    private var isFavorited: Boolean = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_detail_event, container, false)

        // Initialize ViewModels
        viewModel = ViewModelProvider(this)[DetailEventViewModel::class.java]

        // Get the database instance
        val database = FavoritEventDatabase.getInstance(requireContext())
        val factory = FavoritEventViewModelFactory(database)
        favoriteEventViewModel = ViewModelProvider(this, factory)[FavoritEventViewModel::class.java]

        // Initialize UI elements
        imageView = view.findViewById(R.id.imageLogo)
        nameTextView = view.findViewById(R.id.eventName)
        ownerTextView = view.findViewById(R.id.ownerName)
        timeTextView = view.findViewById(R.id.beginTime)
        quotaTextView = view.findViewById(R.id.quota)
        descriptionTextView = view.findViewById(R.id.description)
        linkButton = view.findViewById(R.id.linkButton)
        progressBar = view.findViewById(R.id.progressBar)
        noInternetText = view.findViewById(R.id.no_internet_text)
        favoriteButton = view.findViewById(R.id.favoriteButton)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Get eventId from arguments
        val eventId = arguments?.getString("EVENT_ID") ?: run {
            Log.e("DetailEventFragment", "eventId is null or empty")
            noInternetText.visibility = View.VISIBLE // Show no internet message
            return
        }

        Log.d("DetailEventFragment", "Fetching details for eventId: $eventId")

        // Observer for event detail
        viewModel.eventDetail.observe(viewLifecycleOwner, Observer { event ->
            event?.let {
                updateUI(it)
                // Check if the event ID is not null before calling checkIfFavorited
                it.id?.let { eventId ->
                    checkIfFavorited(eventId) // Check if the event is favorited here
                } ?: run {
                    Log.e("DetailEventFragment", "Event ID is null")
                }
            } ?: run {
                Log.e("DetailEventFragment", "Event detail is null")
                noInternetText.visibility = View.VISIBLE
            }
        })

        // Observer for loading status
        viewModel.isLoading.observe(viewLifecycleOwner, Observer { isLoading ->
            progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        })

        // Observer for internet status
        viewModel.noInternet.observe(viewLifecycleOwner, Observer { noInternet ->
            noInternetText.visibility = if (noInternet) View.VISIBLE else View.GONE
            linkButton.visibility = if (noInternet) View.GONE else View.VISIBLE
            favoriteButton.visibility = if (noInternet) View.GONE else View.VISIBLE
        })

        // Fetch event details
        fetchEventDetails(eventId)

        linkButton.setOnClickListener {
            // Ensure that the event link is not null and safely handle it
            val eventLink = arguments?.getString("EVENT_LINK") ?: ""
            if (eventLink.isNotEmpty()) {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(eventLink)))
            } else {
                Log.e("DetailEventFragment", "Event link is null or empty")
            }
        }

        favoriteButton.setOnClickListener {
            toggleFavorite(eventId)
        }
    }

    private fun toggleFavorite(eventId: String) {
        val currentEvent = viewModel.eventDetail.value
        if (currentEvent != null) {
            isFavorited = !isFavorited
            updateFavoriteIcon()
            lifecycleScope.launch(Dispatchers.IO) {
                if (isFavorited) {
                    favoriteEventViewModel.addFavoriteEvent(convertToFavoritEvent(currentEvent))
                } else {
                    favoriteEventViewModel.removeFavoriteEvent(eventId)
                }
            }
        } else {
            Log.e("DetailEventFragment", "Current event is null while toggling favorite")
        }
    }

    private fun convertToFavoritEvent(event: EventData): FavoritEvent {
        return FavoritEvent(
            summary = event.description ?: "",
            mediaCover = event.mediaCover ?: "",
            registrants = event.registrants ?: 0,
            imageLogo = event.imageLogo ?: "",
            link = event.link ?: "",
            description = event.description ?: "",
            ownerName = event.ownerName ?: "",
            cityName = event.cityName ?: "",
            quota = event.quota ?: 0,
            name = event.name ?: "",
            id = event.id ?: "",
            beginTime = event.beginTime ?: "",
            endTime = event.endTime ?: "",
            category = event.category ?: ""
        )
    }

    private fun fetchEventDetails(eventId: String) {
        viewModel.setLoading(true)

        val apiService = ApiClient.instance.create(ApiService::class.java)
        apiService.getEventDetails(eventId).enqueue(object : Callback<EventDetail> {
            override fun onResponse(call: Call<EventDetail>, response: Response<EventDetail>) {
                viewModel.setLoading(false)

                if (response.isSuccessful && response.body() != null) {
                    response.body()?.event?.let { event ->
                        viewModel.setEventDetail(event)
                    } ?: run {
                        Log.e("DetailEventFragment", "Event is null in response")
                    }
                } else {
                    Log.e("DetailEventFragment", "Error fetching event details: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<EventDetail>, t: Throwable) {
                viewModel.setLoading(false)
                Log.e("DetailEventFragment", "Error fetching event details: ${t.message}")
            }
        })
    }

    private fun updateUI(event: EventData) {
        nameTextView.text = event.name
        ownerTextView.text = event.ownerName
        timeTextView.text = "${event.beginTime} - ${event.endTime}"

        // Menghitung sisa kuota dan menampilkannya
        val remainingQuota = (event.quota ?: 0) - (event.registrants ?: 0)
        quotaTextView.text = "Sisa Kuota: $remainingQuota"

        descriptionTextView.text = Html.fromHtml(event.description, Html.FROM_HTML_MODE_COMPACT)
        Glide.with(this).load(event.imageLogo).into(imageView)
    }

    private fun checkIfFavorited(eventId: String) {
        favoriteEventViewModel.favoriteEvents.observe(viewLifecycleOwner) { events ->
            isFavorited = events.any { it.id == eventId }
            updateFavoriteIcon()
        }
    }

    private fun updateFavoriteIcon() {
        favoriteButton.setImageResource(
            if (isFavorited) R.drawable.ic_favorite else R.drawable.ic_favorite_border
        )
    }

    private fun isInternetAvailable(): Boolean {
        val connectivityManager = context?.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val networkInfo = connectivityManager?.activeNetworkInfo
        return networkInfo != null && networkInfo.isConnected
    }
}
