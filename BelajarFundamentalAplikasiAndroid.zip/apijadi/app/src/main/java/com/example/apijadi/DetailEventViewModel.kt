package com.example.apijadi

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class DetailEventViewModel : ViewModel() {
    private val _eventDetail = MutableLiveData<EventData?>()
    val eventDetail: LiveData<EventData?> get() = _eventDetail

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> get() = _isLoading

    private val _noInternet = MutableLiveData<Boolean>()
    val noInternet: LiveData<Boolean> get() = _noInternet

    fun setEventDetail(event: EventData) {
        _eventDetail.value = event
    }

    fun setLoading(loading: Boolean) {
        _isLoading.value = loading
    }

    fun setNoInternetStatus(noInternet: Boolean) {
        _noInternet.value = noInternet
    }
}
