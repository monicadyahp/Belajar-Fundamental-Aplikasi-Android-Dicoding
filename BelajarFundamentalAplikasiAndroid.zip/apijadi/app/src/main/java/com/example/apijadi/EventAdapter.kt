package com.example.apijadi

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class EventAdapter(private var eventList: List<Event?>) : RecyclerView.Adapter<EventAdapter.EventViewHolder>() {

    class EventViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val eventImage: ImageView = itemView.findViewById(R.id.eventImage)
        val eventName: TextView = itemView.findViewById(R.id.eventName)
        val eventDate: TextView = itemView.findViewById(R.id.eventDate)
        val eventCity: TextView = itemView.findViewById(R.id.eventCity)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_event, parent, false)
        return EventViewHolder(view)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        val event = eventList[position]

        holder.eventName.text = event?.name ?: "N/A"
        holder.eventDate.text = event?.beginTime ?: "N/A"
        holder.eventCity.text = event?.cityName ?: "N/A"


        Glide.with(holder.itemView.context)
            .load(event?.mediaCover ?: event?.imageLogo)
            .into(holder.eventImage)


        holder.itemView.setOnClickListener {
            val fragment = DetailEventFragment()
            val bundle = Bundle().apply {
                putString("EVENT_ID", event?.id?.toString())
                putString("EVENT_LINK", event?.link)
            }
            fragment.arguments = bundle


            val fragmentManager = (holder.itemView.context as AppCompatActivity).supportFragmentManager
            fragmentManager.beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .addToBackStack(null)
                .commit()
        }
    }

    override fun getItemCount(): Int {
        return eventList.size
    }


    fun updateData(newEventList: List<Event?>) {
        eventList = newEventList
        notifyDataSetChanged()
    }
}