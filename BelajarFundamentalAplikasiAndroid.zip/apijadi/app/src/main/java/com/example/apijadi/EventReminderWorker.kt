package com.example.apijadi

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.example.apijadi.ApiService
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class EventReminderWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    override fun doWork(): Result {
        val apiService = createApiService()
        val call = apiService.getEvents(active = -1, limit = 1)

        call.enqueue(object : Callback<ApiResponse> {
            override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                if (response.isSuccessful && response.body() != null) {
                    val event = response.body()!!.listEvents?.firstOrNull()
                    event?.let {

                        val sharedPreferences: SharedPreferences = applicationContext.getSharedPreferences("MyPreferences", Context.MODE_PRIVATE)
                        val isNotificationEnabled = sharedPreferences.getBoolean("notification_enabled", true)

                        if (isNotificationEnabled) {
                            sendNotification(it.name ?: "Event Tanpa Nama", it.beginTime ?: "Waktu Tidak Diketahui")
                        }
                    }
                }
            }

            override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                Log.e("EventReminderWorker", "Failed to fetch events", t)
            }
        })

        return Result.success()
    }

    private fun createApiService(): ApiService {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://event-api.dicoding.dev/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        return retrofit.create(ApiService::class.java)
    }

    private fun sendNotification(eventName: String, eventBeginTime: String) {
        val notificationManager = NotificationManagerCompat.from(applicationContext)

        val notificationId = 1
        val channelId = "event_reminder_channel"


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Event Reminder",
                NotificationManager.IMPORTANCE_HIGH
            )
            notificationManager.createNotificationChannel(channel)
        }

        val builder = NotificationCompat.Builder(applicationContext, channelId)
            .setSmallIcon(R.drawable.logo_event)
            .setContentTitle(eventName)
            .setContentText("Event dimulai pada: $eventBeginTime")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        notificationManager.notify(notificationId, builder.build())
    }
}
