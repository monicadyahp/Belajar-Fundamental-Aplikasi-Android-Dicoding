package com.example.apijadi

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class FavoritEventAdapter(
    private var eventList: List<FavoritEvent>,
    private val onItemClick: (FavoritEvent) -> Unit
) : RecyclerView.Adapter<FavoritEventAdapter.ViewHolder>() {

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val eventImage: ImageView = view.findViewById(R.id.eventImage)
        val eventName: TextView = view.findViewById(R.id.eventName)
        val eventDate: TextView = view.findViewById(R.id.eventDate)
        val eventCity: TextView = view.findViewById(R.id.eventCity)

        init {
            view.setOnClickListener {
                onItemClick(eventList[adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_event, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val event = eventList[position]
        holder.eventName.text = event.name
        holder.eventDate.text = "${event.beginTime} - ${event.endTime}"
        holder.eventCity.text = event.cityName

        Glide.with(holder.eventImage.context).load(event.imageLogo).into(holder.eventImage)
    }

    override fun getItemCount(): Int {
        return eventList.size
    }

    fun updateEvents(newEventList: List<FavoritEvent>) {
        eventList = newEventList
        notifyDataSetChanged()
    }
}
