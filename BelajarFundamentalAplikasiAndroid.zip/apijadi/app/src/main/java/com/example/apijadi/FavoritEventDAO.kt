package com.example.apijadi

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Delete

@Dao
interface FavoritEventDao {

    @Insert
    suspend fun insert(event: FavoritEvent)

    @Query("SELECT * FROM favorit_event")
    suspend fun getAllFavoriteEvents(): List<FavoritEvent>

    @Query("DELETE FROM favorit_event WHERE id = :eventId")
    suspend fun deleteById(eventId: String)
}
