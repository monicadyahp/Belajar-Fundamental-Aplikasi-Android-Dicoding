package com.example.apijadi

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import android.content.Context

@Database(entities = [FavoritEvent::class], version = 1)
abstract class FavoritEventDatabase : RoomDatabase() {

    abstract fun favoritEventDao(): FavoritEventDao

    companion object {
        @Volatile
        private var INSTANCE: FavoritEventDatabase? = null

        fun getInstance(context: Context): FavoritEventDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    FavoritEventDatabase::class.java,
                    "favorit_event_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
