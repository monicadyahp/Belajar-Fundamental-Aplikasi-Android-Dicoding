package com.example.apijadi

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class FavoritEventViewModel(private val database: FavoritEventDatabase) : ViewModel() {

    private val _favoriteEvents = MutableLiveData<List<FavoritEvent>>()
    val favoriteEvents: LiveData<List<FavoritEvent>> get() = _favoriteEvents

    private val _noInternet = MutableLiveData<Boolean>()
    val noInternet: LiveData<Boolean> get() = _noInternet

    init {
        fetchFavoriteEvents()
    }

    fun fetchFavoriteEvents() {
        viewModelScope.launch {
            _favoriteEvents.value = database.favoritEventDao().getAllFavoriteEvents()
        }
    }

    fun addFavoriteEvent(event: FavoritEvent) {
        viewModelScope.launch {
            database.favoritEventDao().insert(event)
            fetchFavoriteEvents()
        }
    }

    fun removeFavoriteEvent(eventId: String) {
        viewModelScope.launch {
            database.favoritEventDao().deleteById(eventId)
            fetchFavoriteEvents() // Memastikan data diperbarui setelah menghapus event
        }
    }
}
