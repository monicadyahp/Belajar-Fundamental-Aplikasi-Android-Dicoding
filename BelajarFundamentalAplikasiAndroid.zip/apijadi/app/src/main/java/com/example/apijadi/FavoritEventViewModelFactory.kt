package com.example.apijadi

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider

class FavoritEventViewModelFactory(private val database: FavoritEventDatabase) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FavoritEventViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return FavoritEventViewModel(database) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
