package com.example.apijadi

import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Favorit_Event : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var noEventText: TextView
    private lateinit var noResultsText: TextView
    private lateinit var viewModel: FavoritEventViewModel
    private lateinit var adapter: FavoritEventAdapter

    private var allFavoriteEvents: List<FavoritEvent> = emptyList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_favorit_event, container, false)

        recyclerView = view.findViewById(R.id.favorit_recyclerview)
        noEventText = view.findViewById(R.id.no_favorit_event)

        noResultsText = TextView(requireContext()).apply {
            text = "Tidak Ada Hasil"
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.CENTER
                marginStart = 16
                marginEnd = 16
            }
            setPadding(16, 16, 16, 16)
        }

        (view as ViewGroup).addView(noResultsText)

        val database = FavoritEventDatabase.getInstance(requireContext())
        val factory = FavoritEventViewModelFactory(database)
        viewModel = ViewModelProvider(this, factory)[FavoritEventViewModel::class.java]

        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        adapter = FavoritEventAdapter(emptyList()) { event ->
            openDetailEvent(event)
        }
        recyclerView.adapter = adapter

        observeFavoriteEvents()

        return view
    }

    override fun onResume() {
        super.onResume()
        // Memastikan data favorit terbaru diambil kembali ketika fragment ditampilkan kembali
        viewModel.fetchFavoriteEvents()
    }

    private fun observeFavoriteEvents() {
        viewModel.favoriteEvents.observe(viewLifecycleOwner, Observer { eventList ->
            if (eventList != null && eventList.isNotEmpty()) {
                noEventText.visibility = View.GONE
                noResultsText.visibility = View.GONE
                recyclerView.visibility = View.VISIBLE
                allFavoriteEvents = eventList
                adapter.updateEvents(allFavoriteEvents)
            } else {
                noEventText.visibility = View.VISIBLE
                noResultsText.visibility = View.GONE
                recyclerView.visibility = View.GONE
            }
        })
    }

    private fun openDetailEvent(event: FavoritEvent) {
        val detailFragment = DetailEventFragment().apply {
            arguments = Bundle().apply {
                putString("EVENT_ID", event.id)
                putString("EVENT_LINK", event.link)
            }
        }
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, detailFragment)
            .addToBackStack(null)
            .commit()
    }

    fun filterEvents(query: String?) {
        val filteredEvents = if (query.isNullOrEmpty()) {
            allFavoriteEvents
        } else {
            allFavoriteEvents.filter { event ->
                event.name?.contains(query, ignoreCase = true) == true
            }
        }

        adapter.updateEvents(filteredEvents)

        if (filteredEvents.isNotEmpty()) {
            recyclerView.visibility = View.VISIBLE
            noEventText.visibility = View.GONE
            noResultsText.visibility = View.GONE
        } else if (allFavoriteEvents.isNotEmpty()) {
            recyclerView.visibility = View.GONE
            noEventText.visibility = View.GONE
            noResultsText.visibility = View.VISIBLE
        } else {
            recyclerView.visibility = View.GONE
            noEventText.visibility = View.VISIBLE
            noResultsText.visibility = View.GONE
        }
    }
}
