package com.example.apijadi

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class FinishedEventViewModel : ViewModel() {
    private val _events = MutableLiveData<List<Event?>>()
    val events: LiveData<List<Event?>> = _events

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _noInternet = MutableLiveData<Boolean>()
    val noInternet: LiveData<Boolean> = _noInternet

    fun setEvents(events: List<Event?>) {
        _events.value = events
    }

    fun setLoading(loading: Boolean) {
        _isLoading.value = loading
    }

    fun setNoInternetStatus(noInternet: Boolean) {
        _noInternet.value = noInternet
    }
}