package com.example.apijadi

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class HomeViewModel : ViewModel() {
    private val _upcomingEvents = MutableLiveData<List<Event?>>()
    val upcomingEvents: LiveData<List<Event?>> = _upcomingEvents

    private val _pastEvents = MutableLiveData<List<Event?>>()
    val pastEvents: LiveData<List<Event?>> = _pastEvents

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _noInternet = MutableLiveData<Boolean>()
    val noInternet: LiveData<Boolean> = _noInternet

    fun setUpcomingEvents(events: List<Event?>) {
        _upcomingEvents.value = events
    }

    fun setPastEvents(events: List<Event?>) {
        _pastEvents.value = events
    }

    fun setLoading(loading: Boolean) {
        _isLoading.value = loading
    }

    fun setNoInternetStatus(noInternet: Boolean) {
        _noInternet.value = noInternet
    }
}