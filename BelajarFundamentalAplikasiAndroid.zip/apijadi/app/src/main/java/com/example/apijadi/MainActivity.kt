package com.example.apijadi

import android.content.SharedPreferences
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SearchView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import android.preference.PreferenceManager
import android.view.View
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var btnFavorit: LinearLayout
    private lateinit var btnUpcoming: LinearLayout
    private lateinit var btnHome: LinearLayout
    private lateinit var btnPast: LinearLayout
    private lateinit var btnSettings: LinearLayout
    private lateinit var searchView: SearchView
    private var activeButtonTag: String? = null
    private var isSearchViewHidden = false

    private lateinit var sharedPreferences: SharedPreferences
    private var favoritFragment: Favorit_Event? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)


        val currentTheme = sharedPreferences.getInt("theme", AppCompatDelegate.MODE_NIGHT_NO)
        AppCompatDelegate.setDefaultNightMode(currentTheme)

        setContentView(R.layout.activity_main)


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        btnFavorit = findViewById(R.id.btnFavorit)
        btnUpcoming = findViewById(R.id.btnUpcoming)
        btnHome = findViewById(R.id.btnHome)
        btnPast = findViewById(R.id.btnPast)
        btnSettings = findViewById(R.id.btnSetting)
        searchView = findViewById(R.id.searchView)

        if (savedInstanceState != null) {
            activeButtonTag = savedInstanceState.getString("ACTIVE_BUTTON")
            isSearchViewHidden = savedInstanceState.getBoolean("SEARCH_VIEW_HIDDEN", false)
            if (isSearchViewHidden) {
                searchView.hide()
            }
        }

        if (savedInstanceState == null) {
            showFragment(home(), false)
            highlightButton(btnHome)
            activeButtonTag = "HOME"
        } else {
            when (activeButtonTag) {
                "HOME" -> highlightButton(btnHome)
                "UPCOMING" -> highlightButton(btnUpcoming)
                "PAST" -> highlightButton(btnPast)
                "SETTINGS" -> {
                    highlightButton(btnSettings)
                    searchView.hide()
                }
                "FAVORIT" -> {
                    favoritFragment = Favorit_Event()
                    highlightButton(btnFavorit)
                }
            }
        }

        setupButtonListeners()
        setupSearchView()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("ACTIVE_BUTTON", activeButtonTag)
        outState.putBoolean("SEARCH_VIEW_HIDDEN", isSearchViewHidden)
    }

    private fun setupButtonListeners() {
        btnFavorit.setOnClickListener {
            favoritFragment = Favorit_Event()
            showFragment(favoritFragment!!, true)
            highlightButton(btnFavorit)
            activeButtonTag = "FAVORIT"
            searchView.show()
        }

        btnUpcoming.setOnClickListener {
            showFragment(upcoming_event(), true)
            highlightButton(btnUpcoming)
            activeButtonTag = "UPCOMING"
            searchView.show()
        }

        btnHome.setOnClickListener {
            showFragment(home(), false)
            highlightButton(btnHome)
            activeButtonTag = "HOME"
            searchView.show()
        }

        btnPast.setOnClickListener {
            showFragment(finished_event(), true)
            highlightButton(btnPast)
            activeButtonTag = "PAST"
            searchView.show()
        }

        btnSettings.setOnClickListener {
            showFragment(SettingFragment(), true)
            highlightButton(btnSettings)
            activeButtonTag = "SETTINGS"
            searchView.hide()
        }
    }

    private fun setupSearchView() {
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (!query.isNullOrEmpty()) {

                    if (activeButtonTag == "FAVORIT") {
                        favoritFragment?.filterEvents(query)
                    } else {

                        when (activeButtonTag) {
                            "HOME" -> searchEvents(query, -1)
                            "UPCOMING" -> searchEvents(query, 1)
                            "PAST" -> searchEvents(query, 0)
                        }
                    }
                }
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                return false
            }
        })
    }

    private fun searchEvents(query: String, eventType: Int) {
        val apiService = ApiClient.instance.create(ApiService::class.java)
        apiService.searchEvents(active = eventType, keyword = query).enqueue(object : Callback<ApiResponse> {
            override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                if (response.isSuccessful) {
                    val events = response.body()?.listEvents
                    showSearchResults(events)
                }
            }

            override fun onFailure(call: Call<ApiResponse>, t: Throwable) {

            }
        })
    }

    private fun showSearchResults(events: List<Event?>?) {
        val fragment = SearchResults.newInstance(events)
        showFragment(fragment, true)
    }

    private fun showFragment(fragment: Fragment, addToBackStack: Boolean) {
        val transaction = supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)

        if (addToBackStack) {
            transaction.addToBackStack(null)
        }

        transaction.commit()
    }

    private fun highlightButton(activeButton: LinearLayout) {
        resetButtonStyle(btnFavorit)
        resetButtonStyle(btnUpcoming)
        resetButtonStyle(btnHome)
        resetButtonStyle(btnPast)
        resetButtonStyle(btnSettings)

        when (activeButton) {
            btnFavorit -> {
                activeButton.findViewById<TextView>(R.id.favorit_text).setTextColor(
                    ContextCompat.getColor(this, R.color.white)
                )
                activeButton.findViewById<ImageView>(R.id.favorit_image).setColorFilter(
                    ContextCompat.getColor(this, R.color.white)
                )
            }
            btnUpcoming -> {
                activeButton.findViewById<TextView>(R.id.upcoming_text).setTextColor(
                    ContextCompat.getColor(this, R.color.white)
                )
                activeButton.findViewById<ImageView>(R.id.upcoming_image).setColorFilter(
                    ContextCompat.getColor(this, R.color.white)
                )
            }
            btnHome -> {
                activeButton.findViewById<TextView>(R.id.home_text).setTextColor(
                    ContextCompat.getColor(this, R.color.white)
                )
                activeButton.findViewById<ImageView>(R.id.home_image).setColorFilter(
                    ContextCompat.getColor(this, R.color.white)
                )
            }
            btnPast -> {
                activeButton.findViewById<TextView>(R.id.past_text).setTextColor(
                    ContextCompat.getColor(this, R.color.white)
                )
                activeButton.findViewById<ImageView>(R.id.past_image).setColorFilter(
                    ContextCompat.getColor(this, R.color.white)
                )
            }
            btnSettings -> {
                activeButton.findViewById<TextView>(R.id.setting_text).setTextColor(
                    ContextCompat.getColor(this, R.color.white)
                )
                activeButton.findViewById<ImageView>(R.id.setting_image).setColorFilter(
                    ContextCompat.getColor(this, R.color.white)
                )
            }
        }

        activeButton.setBackgroundColor(ContextCompat.getColor(this, R.color.colorPrimary))
    }

    private fun resetButtonStyle(button: LinearLayout) {
        when (button) {
            btnFavorit -> {
                button.findViewById<TextView>(R.id.favorit_text).setTextColor(
                    ContextCompat.getColor(this, R.color.black)
                )
                button.findViewById<ImageView>(R.id.favorit_image).setColorFilter(
                    ContextCompat.getColor(this, R.color.black)
                )
            }
            btnUpcoming -> {
                button.findViewById<TextView>(R.id.upcoming_text).setTextColor(
                    ContextCompat.getColor(this, R.color.black)
                )
                button.findViewById<ImageView>(R.id.upcoming_image).setColorFilter(
                    ContextCompat.getColor(this, R.color.black)
                )
            }
            btnHome -> {
                button.findViewById<TextView>(R.id.home_text).setTextColor(
                    ContextCompat.getColor(this, R.color.black)
                )
                button.findViewById<ImageView>(R.id.home_image).setColorFilter(
                    ContextCompat.getColor(this, R.color.black)
                )
            }
            btnPast -> {
                button.findViewById<TextView>(R.id.past_text).setTextColor(
                    ContextCompat.getColor(this, R.color.black)
                )
                button.findViewById<ImageView>(R.id.past_image).setColorFilter(
                    ContextCompat.getColor(this, R.color.black)
                )
            }
            btnSettings -> {
                button.findViewById<TextView>(R.id.setting_text).setTextColor(
                    ContextCompat.getColor(this, R.color.black)
                )
                button.findViewById<ImageView>(R.id.setting_image).setColorFilter(
                    ContextCompat.getColor(this, R.color.black)
                )
            }
        }

        button.setBackgroundColor(ContextCompat.getColor(this, android.R.color.transparent))
    }

    private fun SearchView.hide() {
        this.isIconified = true
        this.clearFocus()
        this.visibility = View.GONE
        isSearchViewHidden = true
    }

    private fun SearchView.show() {
        this.isIconified = false
        this.clearFocus()
        this.visibility = View.VISIBLE
        isSearchViewHidden = false
    }

    fun changeTheme(themeMode: Int) {

        with(sharedPreferences.edit()) {
            putInt("theme", themeMode)
            apply()
        }

        AppCompatDelegate.setDefaultNightMode(themeMode)
    }
}
