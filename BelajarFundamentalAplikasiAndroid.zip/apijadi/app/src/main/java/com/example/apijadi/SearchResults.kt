package com.example.apijadi

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class SearchResults : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: EventAdapter
    private var eventList: List<Event?>? = null
    private lateinit var noResultsTextView: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_search_results, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        recyclerView = view.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(context)

        noResultsTextView = view.findViewById(R.id.noResultsTextView)

        eventList?.let {

            val filteredEvents = it.filterNotNull()
            if (filteredEvents.isEmpty()) {

                noResultsTextView.visibility = View.VISIBLE
                recyclerView.visibility = View.GONE
            } else {

                adapter = EventAdapter(filteredEvents)
                recyclerView.adapter = adapter
                recyclerView.visibility = View.VISIBLE
                noResultsTextView.visibility = View.GONE
            }
        }
    }

    companion object {
        fun newInstance(events: List<Event?>?): SearchResults {
            val fragment = SearchResults()
            fragment.eventList = events
            return fragment
        }
    }
}
