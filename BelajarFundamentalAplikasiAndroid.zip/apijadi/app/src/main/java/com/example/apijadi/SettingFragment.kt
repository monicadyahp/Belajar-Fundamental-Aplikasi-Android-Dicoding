package com.example.apijadi

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.preference.PreferenceManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkRequest
import java.util.concurrent.TimeUnit

class SettingFragment : Fragment() {

    private lateinit var switchTheme: Switch
    private lateinit var switchNotification: Switch
    private lateinit var sharedPreferences: SharedPreferences

    companion object {
        private const val REQUEST_CODE_NOTIFICATION_PERMISSION = 100
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.setting, container, false)

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(requireContext())

        switchTheme = view.findViewById(R.id.switchTheme)
        switchNotification = view.findViewById(R.id.switchNotification)

        // Set initial state for switches
        switchTheme.isChecked = sharedPreferences.getInt("theme", AppCompatDelegate.MODE_NIGHT_NO) == AppCompatDelegate.MODE_NIGHT_YES
        switchNotification.isChecked = sharedPreferences.getBoolean("notification_enabled", false)

        // Switch listeners
        switchTheme.setOnCheckedChangeListener { _, isChecked ->
            setTheme(if (isChecked) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO)
        }

        switchNotification.setOnCheckedChangeListener { _, isChecked ->
            saveNotificationPreference(isChecked)
            if (isChecked) {
                checkNotificationPermission()
            } else {
                cancelDailyReminder()
            }
        }

        return view
    }

    private fun setTheme(mode: Int) {
        AppCompatDelegate.setDefaultNightMode(mode)
        saveThemePreference(mode)
        activity?.recreate()
    }

    private fun saveThemePreference(mode: Int) {
        sharedPreferences.edit().putInt("theme", mode).apply()
    }

    private fun saveNotificationPreference(isEnabled: Boolean) {
        sharedPreferences.edit().putBoolean("notification_enabled", isEnabled).apply()
    }

    private fun checkNotificationPermission() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(requireActivity(),
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                REQUEST_CODE_NOTIFICATION_PERMISSION)
        } else {

            scheduleDailyReminder()
        }
    }

    private fun scheduleDailyReminder() {
        val workRequest: WorkRequest = PeriodicWorkRequestBuilder<EventReminderWorker>(1, TimeUnit.DAYS)
            .addTag("DailyReminder")
            .build()
        WorkManager.getInstance(requireContext()).enqueue(workRequest)
    }

    private fun cancelDailyReminder() {
        WorkManager.getInstance(requireContext()).cancelAllWorkByTag("DailyReminder")
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_NOTIFICATION_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                scheduleDailyReminder()
            } else {

                Toast.makeText(requireContext(), "Izin notifikasi diperlukan", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
