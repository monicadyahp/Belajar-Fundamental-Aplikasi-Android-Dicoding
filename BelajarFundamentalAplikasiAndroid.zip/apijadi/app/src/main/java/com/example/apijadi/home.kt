package com.example.apijadi

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class home : Fragment() {

    private lateinit var upcomingRecyclerView: RecyclerView
    private lateinit var pastRecyclerView: RecyclerView
    private lateinit var upcomingEventAdapter: EventAdapter
    private lateinit var pastEventAdapter: EventAdapter
    private lateinit var upcomingProgressBar: ProgressBar
    private lateinit var pastProgressBar: ProgressBar
    private lateinit var noInternetText: TextView

    private lateinit var viewModel: HomeViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        viewModel = ViewModelProvider(this)[HomeViewModel::class.java]

        // Initialize RecyclerViews and Adapters
        upcomingRecyclerView = view.findViewById(R.id.upcoming_recyclerview)
        upcomingRecyclerView.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        upcomingEventAdapter = EventAdapter(emptyList())
        upcomingRecyclerView.adapter = upcomingEventAdapter

        pastRecyclerView = view.findViewById(R.id.past_recyclerview)
        pastRecyclerView.layoutManager = LinearLayoutManager(requireContext(), LinearLayoutManager.VERTICAL, false)
        pastEventAdapter = EventAdapter(emptyList())
        pastRecyclerView.adapter = pastEventAdapter

        // Initialize ProgressBars
        upcomingProgressBar = view.findViewById(R.id.upcoming_loading)
        pastProgressBar = view.findViewById(R.id.past_loading)

        noInternetText = view.findViewById(R.id.no_internet_text)

        // Observe ViewModel
        viewModel.upcomingEvents.observe(viewLifecycleOwner, Observer { events ->
            upcomingProgressBar.visibility = View.GONE
            if (events.isNotEmpty()) {
                upcomingEventAdapter.updateData(events)
            }
        })

        viewModel.pastEvents.observe(viewLifecycleOwner, Observer { events ->
            pastProgressBar.visibility = View.GONE
            if (events.isNotEmpty()) {
                pastEventAdapter.updateData(events)
            }
        })

        viewModel.noInternet.observe(viewLifecycleOwner, Observer { noInternet ->
            if (noInternet) {
                noInternetText.visibility = View.VISIBLE
                upcomingRecyclerView.visibility = View.GONE
                pastRecyclerView.visibility = View.GONE
                upcomingProgressBar.visibility = View.GONE
                pastProgressBar.visibility = View.GONE
            } else {
                noInternetText.visibility = View.GONE
                upcomingRecyclerView.visibility = View.VISIBLE
                pastRecyclerView.visibility = View.VISIBLE
            }
        })

        // Check and load data
        if (viewModel.upcomingEvents.value.isNullOrEmpty()) {
            upcomingProgressBar.visibility = View.VISIBLE
            if (isInternetAvailable(requireContext())) fetchDataFromApi(upcoming = true)
            else viewModel.setNoInternetStatus(true)
        }

        if (viewModel.pastEvents.value.isNullOrEmpty()) {
            pastProgressBar.visibility = View.VISIBLE
            if (isInternetAvailable(requireContext())) fetchDataFromApi(upcoming = false)
            else viewModel.setNoInternetStatus(true)
        }

        return view
    }

    private fun fetchDataFromApi(upcoming: Boolean) {
        val apiService = getRetrofitInstance().create(ApiService::class.java)

        if (upcoming) {
            apiService.getEvents(1).enqueue(object : Callback<ApiResponse> {
                override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                    upcomingProgressBar.visibility = View.GONE
                    if (response.isSuccessful) {
                        val body = response.body()
                        body?.listEvents?.let { events -> viewModel.setUpcomingEvents(events.filterNotNull().take(5)) }
                    }
                }
                override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                    upcomingProgressBar.visibility = View.GONE
                    viewModel.setNoInternetStatus(true)
                }
            })
        } else {
            apiService.getEvents(0).enqueue(object : Callback<ApiResponse> {
                override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                    pastProgressBar.visibility = View.GONE
                    if (response.isSuccessful) {
                        val body = response.body()
                        body?.listEvents?.let { events -> viewModel.setPastEvents(events.filterNotNull().take(5)) }
                    }
                }
                override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                    pastProgressBar.visibility = View.GONE
                    viewModel.setNoInternetStatus(true)
                }
            })
        }
    }

    private fun getRetrofitInstance(): Retrofit {
        return Retrofit.Builder()
            .baseUrl("https://event-api.dicoding.dev/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    private fun isInternetAvailable(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
    }
}
