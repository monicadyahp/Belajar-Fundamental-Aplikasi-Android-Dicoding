package com.example.apijadi

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class upcoming_event : Fragment() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var eventAdapter: EventAdapter
    private lateinit var progressBar: ProgressBar
    private lateinit var noInternetText: TextView

    private lateinit var viewModel: UpcomingEventViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_upcoming_event, container, false)


        viewModel = ViewModelProvider(this)[UpcomingEventViewModel::class.java]


        recyclerView = view.findViewById(R.id.upcoming_recyclerview)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        eventAdapter = EventAdapter(emptyList())
        recyclerView.adapter = eventAdapter


        progressBar = view.findViewById(R.id.loading)
        noInternetText = view.findViewById(R.id.no_internet_text)


        viewModel.events.observe(viewLifecycleOwner, Observer { events ->
            eventAdapter.updateData(events)
            if (events.isNotEmpty()) {
                recyclerView.visibility = View.VISIBLE
                noInternetText.visibility = View.GONE
            }
        })


        viewModel.isLoading.observe(viewLifecycleOwner, Observer { isLoading ->
            progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
        })


        viewModel.noInternet.observe(viewLifecycleOwner, Observer { noInternet ->
            if (noInternet && viewModel.events.value.isNullOrEmpty()) {
                noInternetText.visibility = View.VISIBLE
                recyclerView.visibility = View.GONE
            }
        })


        if (viewModel.events.value.isNullOrEmpty()) {
            if (isInternetAvailable(requireContext())) {
                fetchDataFromApi()
            } else {
                viewModel.setNoInternetStatus(true)
            }
        }

        return view
    }

    private fun fetchDataFromApi() {
        viewModel.setLoading(true)
        viewModel.setNoInternetStatus(false)

        val apiService = getRetrofitInstance().create(ApiService::class.java)

        apiService.getEvents(1).enqueue(object : Callback<ApiResponse> {
            override fun onResponse(call: Call<ApiResponse>, response: Response<ApiResponse>) {
                viewModel.setLoading(false)
                if (response.isSuccessful) {
                    val body = response.body()
                    body?.listEvents?.let { events ->
                        viewModel.setEvents(events.filterNotNull())
                    }
                } else {
                    Log.e("UpcomingEventFragment", "Response failed: ${response.errorBody()?.string()}")
                }
            }

            override fun onFailure(call: Call<ApiResponse>, t: Throwable) {
                viewModel.setLoading(false)
                Log.e("UpcomingEventFragment", "API call failed: ${t.message}")
            }
        })
    }

    private fun getRetrofitInstance(): Retrofit {
        return Retrofit.Builder()
            .baseUrl("https://event-api.dicoding.dev/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }


    private fun isInternetAvailable(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
    }
}